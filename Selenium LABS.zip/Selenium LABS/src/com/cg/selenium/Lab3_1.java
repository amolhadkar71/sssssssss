package com.cg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Lab3_1 {
	public static String driverpath="C:\\Users\\AMHADKAR\\Desktop\\";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String war1=null,war2=null;
		System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://demo.opencart.com/");
		String actualtitle=driver.getTitle();
		System.out.println(actualtitle);
		if(actualtitle.equals("Your Store"))
			System.out.println("Test Case Passed");
		else
			System.out.println("Test Case Failed");
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.linkText("Register")).click();
		String headtext=driver.findElement(By.xpath("//*[@id='content']/h1")).getText();
		if(headtext.equals("Register Account"))
			System.out.println("Test Case Passed");
		else
			System.out.println("Test Case Failed");
		
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
		
		String war=driver.findElement(By.className("text-danger")).getText();
		System.out.println(war);
		if(war.equals("Warning: You must agree to the Privacy Policy!"))
			System.out.println("Test Case Passed");
		else
			System.out.println("Test Case Failed");
		
		driver.findElement(By.xpath("//*[@id='input-firstname']")).sendKeys("Amoooooooooooooooooooooooooooooooo");
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
		String getFname=driver.findElement(By.xpath("//*[@id='input-firstname']")).getText();
		System.out.println(getFname.length());
		if(getFname.length()>32)
			{
			System.out.println("True");
			/*war1=driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div")).getText();
			if(war1.equals("First Name must be between 1 and 32 characters!"))
				System.out.println("Test Case Passed");
			else
				System.out.println("Test Case Failed");*/
			}
		
		/*driver.findElement(By.xpath("//*[@id='input-lastname']")).sendKeys("Amoooooooooooooooooooooooooooooooo");
			String getLname=driver.findElement(By.xpath("//*[@id='input-lastname']")).getText();
			if(getLname.length()>32)
				{
				war2=driver.findElement(By.xpath("//*[@id='account']/div[3]/div/div")).getText();
				if(war2.equals("Last Name must be between 1 and 32 characters!"))
					System.out.println("Test Case Passed");
				else
					System.out.println("Test Case Failed");	
				}
			//Email
			driver.findElement(By.xpath("//*[@id='input-email']")).sendKeys("abc@gmail.com");	
			driver.findElement(By.xpath("//*[@id='input-telephone']")).sendKeys("022656555");*/
			
			
	}

}
