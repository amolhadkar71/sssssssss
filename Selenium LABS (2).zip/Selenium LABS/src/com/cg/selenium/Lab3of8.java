package com.cg.selenium;

import java.net.MalformedURLException;
import java.net.URL;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class Lab3of8 {
	
	static WebDriver driver;

	
	public static void main(String[] args) throws InterruptedException, MalformedURLException {
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setBrowserName("firefox");
		capabilities.setPlatform(Platform.ANY);
		
		driver = new RemoteWebDriver(new URL("http://10.51.91.84:5566/wd/hub"),capabilities);
		try{
			driver.get("https://demo.opencart.com/");
			driver.manage().window().maximize();
		 String expectedTitle = "Your Store";
	      String actualTitle = driver.getTitle();
		
	      if(expectedTitle.equals(actualTitle))
	    	  System.out.println("Expected title is equal to Actual title");
	      else
	    	  System.out.println("Expected title is not equal to Actual Title");
		
		
		//Click on My Account drop down
	      driver.findElement(By.linkText("My Account")).click();
	      
	      //select Register from drop down
	      driver.findElement(By.linkText("Register")).click();
	      
	      //Assert.assertEquals("Register Account",  driver.findElement(By.xpath("//*[@id='content']/h1")).getText());
	     
	      //Enter data in 'First Name'
	      driver.findElement(By.id("input-firstname")).sendKeys("Amol");
	      
	   
	      
	      //Enter data in 'Last Name'
	      driver.findElement(By.id("input-lastname")).sendKeys("Hadkar");
	     
	      //Enter valid E-mail
	      driver.findElement(By.id("input-email")).sendKeys("amolhadkaraa71711111a@gmail.com");
	      
	      //Enter Telephone Number
	      driver.findElement(By.id("input-telephone" )).sendKeys("9678567843");
	      //Enter 'password' which must be between 4 and 20 characters
	      driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys("amolhadkar7171@");
	      
	      //Enter 'Password Confirm'
	      driver.findElement(By.id("input-confirm")).sendKeys("amolhadkar7171@");
	      Thread.sleep(3000);
	      //click on yes radio button
	      driver.findElement(By.xpath("//*[@id='content']/form/fieldset[3]/div/div/label[2]/input")).click();
	      
	      //click on check box for 'I have read and agree to the privacy polcy'
	      driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[1]")).click();
	      
	      //click on continue button
	      driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
	  					
	      Assert.assertEquals("Your Account Has Been Created!",  driver.findElement(By.xpath("//*[@id='content']/h1")).getText());
	      
	      //click on 'continue'
	      driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
	      
	      //click on link 'View your order history under 'My orders'
	      driver.findElement(By.xpath("//*[@id='content']/ul[2]/li[1]/a")).click();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

	}

}
