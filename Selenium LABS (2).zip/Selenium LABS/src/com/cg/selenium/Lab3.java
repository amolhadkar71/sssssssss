package com.cg.selenium;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.thoughtworks.selenium.webdriven.commands.GetText;

public class Lab3 {
	public static String driverpath="C:\\Users\\AMHADKAR\\Desktop\\";
	public static void main(String []args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("http://demo.opencart.com/");
		//driver.get("https://demo.opencart.com/index.php?route=account/login");
		driver.manage().window().maximize();
		Assert.assertEquals("Your Store", driver.getTitle());
	     //Click on My Account drop down
	      driver.findElement(By.linkText("My Account")).click();
	      
	      //select Register from drop down
	      driver.findElement(By.linkText("Register")).click();
	      String msg1=driver.findElement(By.xpath("//*[@id='content']/h1")).getText();
	      if(msg1.equals("Register Account"))
	    	  System.out.println("Register Account verified");
	      else
	    	  System.out.println("Register Account not verified");
	      driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
	      Thread.sleep(2000);
	      String msg2=driver.findElement(By.xpath("//*[@id='account-register']/div[1]")).getText();
	      //System.out.println(msg2);
	      if(msg2.equals("Warning: You must agree to the Privacy Policy!"))
	    	  System.out.println("Warning message verified");
	      else
	    	  System.out.println("Warning message not verified");
	      
	      //firstname error msg
	      String msg3=driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div")).getText();
	      if(msg3.equals("First Name must be between 1 and 32 characters!"))
	    	  System.out.println("First Name verified");
	      else
	    	  System.out.println("First Name Not verified");
	      //lastname
	      String msg4=driver.findElement(By.xpath("//*[@id='account']/div[3]/div/div")).getText();
	      if(msg4.equals("Last Name must be between 1 and 32 characters!"))
	    	  System.out.println("Last Name verified");
	      else
	    	  System.out.println("Last Name Not verified");
	      //email
	      String msg5=driver.findElement(By.xpath("//*[@id='account']/div[4]/div/div")).getText();
	      if(msg5.equals("E-Mail Address does not appear to be valid!"))
	    	  System.out.println("Email verified");
	      else
	    	  System.out.println("Email Not verified");
	      //telephone
	      String msg6=driver.findElement(By.xpath("//*[@id='account']/div[5]/div/div")).getText();
	      if(msg6.equals("Telephone must be between 3 and 32 characters!"))
	    	  System.out.println("Telephone verified");
	      else
	    	  System.out.println("Telephone Not verified");
	      
	      String msg7=driver.findElement(By.xpath("//*[@id='content']/form/fieldset[2]/div[1]/div/div")).getText();
	      if(msg7.equals("Password must be between 4 and 20 characters!"))
	    	  System.out.println("Password verified");
	      else
	    	  System.out.println("Password Not verified");
	      
	      //part 2
	      
	      //System.out.println(msg3);
	      //System.out.println(msg4);
	      //System.out.println(msg5);
	      //System.out.println(msg6);
	      
	
	      //Enter data in 'First Name'
	      /*driver.findElement(By.id("input-firstname")).sendKeys("Amol");
	      
	   
	      
	      //Enter data in 'Last Name'
	      driver.findElement(By.id("input-lastname")).sendKeys("Hadkar");
	     
	      //Enter valid E-mail
	      driver.findElement(By.id("input-email")).sendKeys("amolhadkara71711111@gmail.com");
	      
	      //Enter Telephone Number
	      driver.findElement(By.id("input-telephone" )).sendKeys("9678567843");
	      //Enter 'password' which must be between 4 and 20 characters
	      driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys("amolhadkar7171@");
	      
	      //Enter 'Password Confirm'
	      driver.findElement(By.id("input-confirm")).sendKeys("amolhadkar7171@");
	      Thread.sleep(3000);
	      //click on yes radio button
	      driver.findElement(By.xpath("//*[@id='content']/form/fieldset[3]/div/div/label[2]/input")).click();
	      
	      //click on check box for 'I have read and agree to the privacy polcy'
	      driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[1]")).click();
	      
	      //click on continue button
	      driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
	  					
	      Assert.assertEquals("Your Account Has Been Created!",  driver.findElement(By.xpath("//*[@id='content']/h1")).getText());
	      
	      //click on 'continue'
	      driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
	      
	      //click on link 'View your order history under 'My orders'
	      driver.findElement(By.xpath("//*[@id='content']/ul[2]/li[1]/a")).click()*/;
	}
}
