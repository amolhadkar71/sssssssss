package com.cg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Lab_5 {
	public static String driverpath="C:\\Users\\AMHADKAR\\Desktop\\";
	public static void main(String []args)
	{
		System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://ispace.ig.capgemini.com/sitepages/index.aspx");
		driver.findElement(By.linkText("APPLICATIONS")).click();
	}
	
}
